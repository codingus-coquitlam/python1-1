try:
  print(name)
except NameError:
  print("The variable is not defined")
except:
  print("Something else went wrong.")
else:
  print("Nothing went wrong")
finally:
  print("The try except has finished")

# What is the variable in the code?
  # Answer

# What purpose does the 'try' have in the code
  # Answer

# What does 'NameError' mean on line 3?
  # Answer

# Why are there two 'except' commands?
  # Answer

# What would happen if lines 6 and 8 were swapped?
  # Answer