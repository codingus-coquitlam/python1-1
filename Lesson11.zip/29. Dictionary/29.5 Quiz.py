# Replace "pass" with return after you've written the code

#1. Write a function that takes a list of integers and returns the sum of the even numbers in the list.

def sum_evens(numbers):
    # your code here
    pass

assert sum_evens([1, 2, 3, 4, 5]) == 6
assert sum_evens([1, 3, 5, 7, 9]) == 0
assert sum_evens([-2, -4, -6, -8]) == -20

#2. Write a function that takes a string and returns a new string with all vowels removed.

def remove_vowels(string):
    # your code here
    pass

assert remove_vowels('hello world') == 'hll wrld'
assert remove_vowels('python') == 'pythn'
assert remove_vowels('aeiou') == ''

#3. Write a function that takes a list of numbers and returns a new list with the duplicates removed.
def remove_duplicates(numbers):
    # your code here
    
    pass

assert remove_duplicates([1, 2, 3, 2, 1]) == [1, 2, 3]
assert remove_duplicates([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
assert remove_duplicates([1, 1, 1, 1, 1]) == [1]

#4. Write a function that takes a string and returns the number of vowels in the string.
def count_vowels(string):
    # your code here
    pass

assert count_vowels('hello world') == 3
assert count_vowels('python') == 2
assert count_vowels('aeiou') == 5

#5. Write a function that takes a list of integers and returns a new list with all the negative numbers removed.
def remove_negatives(numbers):
    # your code here
    pass

assert remove_negatives([-1, -2, -3, 4, 5, 6]) == [4, 5, 6]
assert remove_negatives([1, 2, 3, -4, -5, -6]) == [1, 2, 3]
assert remove_negatives([-1, -1, -1, -1, -1]) == []

#6. Write a function that takes a string and returns a new string where all the characters in the original string are in reverse order.
def reverse_string(string):
    # your code here
    pass

assert reverse_string('hello') == 'olleh'
assert reverse_string('world') == 'dlrow'
assert reverse_string('python') == 'nohtyp'

#7. Write a function that takes a list of numbers and returns a new list where each number is squared.
def square_list(numbers):
    # your cod here
    pass

assert square_list([1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]
assert square_list([-1, -2, -3, -4, -5]) == [1, 4, 9, 16, 25]