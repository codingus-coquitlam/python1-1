# Define a function that takes a dictionary and a key as arguments
# and returns the value associated with the key in the dictionary
def ________(d, key):
  return d[key]

# Define a function that takes a dictionary and a key-value pair as arguments
# and adds the key-value pair to the dictionary
def __________(d, key, value):
  d[key] = value

# Define a dictionary with some initial key-value pairs
my_dict = {
  "name": "sonny",
  "age": 30,
  "email": "sonny@chicken-house.com"
}

# Loop over the keys and values in the dictionary
for key, value in my_dict.items():
  # Use the get_value() function to get the value for the current key
  v = __________(my_dict, key)
  print(key + ":" + str(v) +)

# Add a new key-value pair to the dictionary
# Use the add_pair() function to add the pair
__________(my_dict, "phone", "123-456-7890")

# Loop over the keys and values in the dictionary again
for key, value in my_dict.items():
  # Use the get_value() function to get the value for the current key
  v = __________(my_dict, key)
  print(key + ":" + str(v) +)
