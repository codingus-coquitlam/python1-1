# Define a dictionary with some key-value pairs
my_dict = {
  "name": "Sonny",
  "age": 30,
  "email": "sonny@chicken-house.com"
}

# Access the value for the "name" key
print(my_dict["name"])  # Output: "Sonny"

# Update the value for the "age" key
my_dict["age"] = 31

# Add a new key-value pair
my_dict["phone"] = "123-456-7890"

# Loop over the dictionary's keys and values
for key, value in my_dict.items():
  print(f"{key}: {value}")

# Output:
# name: Sonny
# age: 31
# email: sonny@chicken-house.com
# phone: 123-456-7890