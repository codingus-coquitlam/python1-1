# Define a dictionary with some key-value pairs
my_dict = {
    "name": "Sonny",
  "age": 30,
  "email": "sonny@chicken-house.com"
}

# Access the value for the "name" key
print(my_dict["name"])  # Output: "Sonny"

# Update the value for the "age" key
my_dict["age"] = 31

# Add a new key-value pair
my_dict["phone"] = "123-456-7890"

# Loop over the dictionary's keys and values
for key, value in my_dict.items():
  print(key + ": "+  str(value))

print(my_dict['address'])

# What does the my_dict dictionary contain?
  # Answer

# What does the code do when it accesses the value for the "name" key using the square bracket notation?
  # Answer

# What does the code do when it updates the value for the "age" key using the square bracket notation?
  # Answer

# What does the code do when it adds a new key-value pair using the square bracket notation?
  # Answer

# What happens if the code tries to access the value for a key that does not exist in the dictionary like on line 21?
  # Answer
