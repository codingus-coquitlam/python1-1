manchesterUnited = {"Ronaldo", "Anthony", "Bruno", "Rashford","Dalot", "Varane", "Sancho", "De Gea", "Shaw", }
portugal = {"Pepe", "Otavio", "Leao", "Cancelo", "Bruno","Diaz", "Mendez", "Nevez", "Ronaldo", "Dalot"}

allPlayers = manchesterUnited.union(portugal)

print(allPlayers)

manUnitedLength = 
portugalLength = 
allPlayersLength =

# print Portugese players playing for Man United
# portugueseManUnited = manchesterUnited.intersection(portugal) 
portManU = manchesterUnited & portugal
print(portugueseManUnited)

# print non Portugese players playing for Man United
# nonPortManU = manchesterUnited.difference(portugal)
nonPortManU = manchesterUnited - portugal
print(nonPortManU)

# print portuguese players not playing for Manchester United
nonManUPort = 
print(nonManUPort)

# Ronaldo left Man United last week. Remove Ronaldo from the Man U set and print new set
manchesterUnited
print(manchesterUnited)


