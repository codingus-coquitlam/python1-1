thisset = {"apple", "banana", "cherry", "apple"}

thisset.add("orange")

print(thisset)
print("banana" in thisset)

thisset = {"apple", "banana", "cherry"}
mylist = ["kiwi", "orange"]

thisset.update(mylist)

print(thisset)

# What would be the output of line 6?
  # Answer

# What is the identifier for the set in this program?
  # Answer

# What is the purpose of line 3?
  # Answer

# What is the purpose of line 10?
  # Answer

# What is the purpose of line 6?
  # Answer

# What would be the type of thisset variable after executing line 11? 
  # Answer