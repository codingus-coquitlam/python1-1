round16 = open("/Users/Yulbin/Documents/Python1-2/14. Sets/round16.txt", "r")
round16Countries = set({})

def makeSet (file, setName):
    

