#Tuple with strings
tuple1 = ("apple", "banana", "cherry")

#Tuple with integers
tuple2 = (1, 5, 7, 9, 3)

#Tuple with Boolean values
tuple3 = (True, False, False)

#Tuples can contain different type of values
tuple4 = ("abc", 34, True, 40, "male")

print(tuple1)
print(tuple1[0])
print(tuple1[0:2])
