studentNames = ["messi", "ronaldo", "son", "mbappe"]

messiGrade = (["Physics", 85], ["Math", 86], ["PE", 93], ["English", 88], ["Bio", 94], ["Chemistry", 98])
ronaldoGrade = (["Physics", 83], ["Math", 80], ["PE", 90], ["English", 81], ["Bio", 92], ["Chemistry", 88])
sonGrade = (["Physics", 100], ["Math", 95], ["PE", 90], ["English", 88], ["Bio", 94], ["Chemistry", 92])
mbappeGrade = (["Physics", 95], ["Math", 88], ["PE", 60], ["English", 70], ["Bio", 79], ["Chemistry", 80])

artGrade = [98, 90, 81, 89]
students = [messiGrade, ronaldoGrade, sonGrade, mbappeGrade]



