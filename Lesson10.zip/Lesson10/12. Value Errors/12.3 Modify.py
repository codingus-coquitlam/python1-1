# Starter Code

try:
    num = int(input("Enter a number: "))    
except:
    print("Not an integer!")
else:
    print()