# Example Code

rockStars = ["John","Paul","George","Ringo","Freddie","Brian","John","Roger"]

counter = 0
found = False

while counter < len(rockStars):
  
  if rockStars[counter] == "George":
    found = True

  counter +=1

if found == True:
  print("George is in the list")
else:
  print("George is not in the list")

# What is the purpose of the counter variable?
  # Answer

# What is the purpose of the found variable?
  # Answer

# What does the line counter +=1 do?
  # Answer

# If line 12 was changed to if rockStars[1] what effect would it have on the output and why?
  # Answer

# Why is the selection on line 17 not indented?
  # Answer