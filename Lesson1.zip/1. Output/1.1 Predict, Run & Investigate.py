# Example code

print("Hello World!")

# My Prediction - Add your prediction as a comment below.
 
 # Delete this conmment and replace it with your prediction.


##### Task Investigate

# Which part of the example code is the output statement?
 # Answer: 

# Which part of the example code is the string?
 # Answer: 

# What would the output of the code print("I love Computing") be?
 # Answer: 

# What would happen if the code print("I love Comping") was run?
 # Answer: 

# What would happen if the code print("I love Computing" was run?
 # Answer: 