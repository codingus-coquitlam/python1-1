name = "Billy"
print("We want to know if you like progamming!")
print()
print("Do you like programming " + name + "?")
answer = input()
print("Great, " + name + ", you said " + answer + "!")
print("Let's learn some Python today")

# How many output statements are used in the code?
 # Answer

# What symbol is used for concatenation?
 # Answer

# What is the purpose of the program?
 # Answer 

# What line(s) is assignment used on?
 # Answer

# What symbol is used for assignment?
 # Answer

# What is the purpose of the empty print statement on line 3?
 # Answer