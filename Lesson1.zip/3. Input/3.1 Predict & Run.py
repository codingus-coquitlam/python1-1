#Task 1 - Add comments to the code below to predict what will happen when it is run.

#Task 2 - add comments to the code to explain what the variable(s) are called and where they are used. Make sure to show where the variable.

print("Hi! What's your name?")

name = input()

print("Hi " + name + "! How are you today?")