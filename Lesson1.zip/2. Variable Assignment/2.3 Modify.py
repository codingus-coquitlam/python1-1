# Variable Assignment - Modify

#You can combine variables with strings in an output

name1 = "Lionel"
name2 = "Messi"
#Add 2 more variables to store 'Cristiano' and 'Ronaldo'

#This line uses concatenation to join the variables together with the string 'and' to make a sentence.

#Complete the line to output all of the variables 
print(name1 + " and " + name2 + " and ")