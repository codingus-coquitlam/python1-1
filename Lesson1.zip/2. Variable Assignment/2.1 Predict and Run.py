#Predict and Run Example 1
 # Add comments to the code below to explain what it does

firstName = "Andy"

print(firstName)

#Predict and Run Example 2
 # Add comments to the code below to explain what it does

lastName = "Colley"

fullName = firstName + " " + lastName

print(fullName)

#Predict and Run Example 3
 # Add comments to the code below to explain what it does

print("Hello " + firstName + ". Your full name is " + fullName + ".")

