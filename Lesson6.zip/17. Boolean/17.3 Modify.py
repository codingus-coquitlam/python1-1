# Starter Code

name = "Dave"
homeTown = "Seattle"

if name == "Dave" and homeTown == "Seattle":
  print("Hi there Dave from Seattle!")
else:
  print("You're not Dave from Seattle!")

if name == "Dave" or homeTown == "Seattle":
  print("You're either called Dave or you're from Seattle!")
else:
  print("You're not Dave, and you aren't from Seattle!")