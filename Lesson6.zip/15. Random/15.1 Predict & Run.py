# Example Code

import random

print(random.randint(1,5))

num1 = random.randint(1,10)

print("Your number was " + str(num1))