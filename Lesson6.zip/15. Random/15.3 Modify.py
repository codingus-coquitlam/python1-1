# Starter Code

import random

print("Welcome to the dice simulator!")

num1 = random.randint(1,6)

print("You rolled a " + str(num1))