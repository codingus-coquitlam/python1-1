# Starter Code

name = "Dave"

nameLength = len(name)
nameRemainder = nameLength % 2

if