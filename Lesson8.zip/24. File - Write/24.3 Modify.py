def saveStudent():
  myFile = open('Students.txt','a')  #Creates/Opens Students.txt with append permissions

  print('Enter Student Details: ')
  while True:
    name 
    # It gets input for the student's grade. 
    grade
    # It concatenates the grade data to the line that is appended to the file.
    line 
    myFile.write(line) 

    print('Enter another student? Type yes to continue or no to quit') 
    choice = input()

    # It validates the user's choice so that it only accepts 'yes' or 'no'.
    while choice.lower() :
      print("Invalid input, please try again.")
      choice = input("Type yes to continue or no to quit")

    if choice.lower() == 'no':
      print('Goodbye!')
      break


  myFile.close()

saveStudent()

