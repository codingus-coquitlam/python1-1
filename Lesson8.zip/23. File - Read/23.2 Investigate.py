bandFile = open("bands.txt", "r")

for line in bandFile:
  print(line)

bandFile.close()

# What is the name of the variable used to store the file contents?
  # Answer

# What does 'r' on line 5 do?
  # Answer

# How many variables are used in the code?  What are they called?
  # Answer

# What is the file extension of the file used?
  # Answer