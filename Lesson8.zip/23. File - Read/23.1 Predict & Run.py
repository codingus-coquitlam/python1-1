myFile = open("singers.txt", "r")
for line in myFile:
  print(line)
myFile.close()