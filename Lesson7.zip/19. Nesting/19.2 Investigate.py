# Example Code

name = "Dave"
homeTown = "Seattle"


if name == "Dave":
  print("Hi there Dave, where are you from?")

  if homeTown == "Seattle":
    print("Hi Dave from Seattle!")
  else:
    print("Hi Dave, shame you're not from Seattle.")

else:
  print("You're not Dave where are you from?")

  if homeTown == "Seattle":
    print("Well you might not be Dave, but at least you're from Seattle")
  else:
    print("You're not Dave, and you're not from Seattle!")

# How many selection statements are there in the code?
  # Answer

# How many of them are nested, and how can you tell?
  # Answer

# What would be the impact of swapping lines 7 and 10?
  # Answer