# Example Code

# Example 1

correctUserName = "dave"

print(("Please enter your username"))
userName = input.lower()

while userName != correctUserName:
  userName = input("Username incorrect, please try again.")

print("Username accepted.")

# Example 2

print("Enter a number between 1 and 10")
num1 = int(input())

while num1 < 1 or num1 > 10:
  num1 = input("Invalid number, please try again")

print("Input accepted.")