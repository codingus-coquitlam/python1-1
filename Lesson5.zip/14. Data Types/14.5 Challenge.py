







# Create a function that ouputs result like below lines

# >>> Today's lottery numbers are: 
# [7, 13, 16, 37, 46, 49]
# >>> Your bonus number is 
# 19