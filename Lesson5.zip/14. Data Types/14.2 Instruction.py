num1 = int(input("Enter a number"))
num2 = float(input("Enter another number"))

print(num1)

total = num1 * num2

print(total)

# What does the 'int' before 'input' make the program do?
  # Answer

# What does the 'float' before 'input' make the program do?
  # Answer

# What data type will the output be?
  # Answer