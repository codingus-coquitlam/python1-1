# Example Code

data1 = 2.9
data2 = "Hello World!"
data3 = 6


print(type(data1))
print(type(data3))
print(type(data2))

data1 = data1 + 0.1

print(type(data1))

data3 = float(data3)
data1 = int(data1)

print(type(data1))
print(type(data3))