num1 = float(input("Enter a number"))
num2 = float(input("Enter another number"))

total = num1 * num2

print(int(total))
