"Hello World".upper()

print("Hello World!".lower())

word = "Apricot"

wordUpper = word.upper()

print(wordUpper)

print(word.lower())

# Give the line number where variable assignment is first used.
  # Answer

# What will be stored in the wordUpper variable after line 7 has been executed?
  # Answer

# What will be output by line 11?
  # Answer

# What will be output by line 1?
  # Answer