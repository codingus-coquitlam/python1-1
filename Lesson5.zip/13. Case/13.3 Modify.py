# Starter Code

guess = input("What is the capital of France?")

if guess.lower() == "paris":
  print("Correct!")